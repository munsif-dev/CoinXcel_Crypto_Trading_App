package com.munsif.CoinXcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinXcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
